package br.com.projetoVerao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoVeraoApplicationTests {

	@Test
	void contextLoads() {
	}

}
